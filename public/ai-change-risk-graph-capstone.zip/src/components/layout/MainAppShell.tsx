import React, { useState } from 'react';
import { 
  Network, 
  GitCommit, 
  CheckSquare, 
  Sliders, 
  FlaskConical, 
  History, 
  ShieldCheck, 
  FolderGit2,
  Terminal,
  Activity,
  Layers,
  Zap,
  Play,
  ArrowRight,
  GitBranch,
  RefreshCw,
  Download
} from 'lucide-react';
import { PRECONFIGURED_ANALYSES } from '../../mockData.ts';
import { DEMO_REPOSITORIES } from '../../data/repositories.ts';
import { RepositorySummary } from '../../types/repository.ts';
import { AnalysisResult, GraphNode } from '../../types.ts';
import { ChangeSummaryPanel } from '../workspace/ChangeSummaryPanel.tsx';
import { GraphCanvas } from '../workspace/GraphCanvas.tsx';
import { RiskEvidencePanel } from '../workspace/RiskEvidencePanel.tsx';
import { TestRecommendationTable } from '../workspace/TestRecommendationTable.tsx';
import { WhatIfReleaseView } from '../workspace/WhatIfReleaseView.tsx';
import { ResearchEvaluationView } from '../workspace/ResearchEvaluationView.tsx';
import { HistoryFeedbackView } from '../workspace/HistoryFeedbackView.tsx';
import { SecurityAuditView } from '../workspace/SecurityAuditView.tsx';
import { RepositoryExplorerView } from '../workspace/RepositoryExplorerView.tsx';
import { ImportRepositoryModal } from '../workspace/ImportRepositoryModal.tsx';

export const MainAppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'REPOSITORIES' | 'WORKSPACE' | 'TESTS' | 'WHAT_IF' | 'RESEARCH' | 'HISTORY' | 'SECURITY'>('WORKSPACE');
  const [selectedRepo, setSelectedRepo] = useState<RepositorySummary>(DEMO_REPOSITORIES[0]); // Default: College Management
  const [selectedCommitKey, setSelectedCommitKey] = useState<string>('college-commit-enrollment');
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Dynamic analysis based on selected commit / repository
  const currentAnalysis: AnalysisResult = PRECONFIGURED_ANALYSES[selectedCommitKey] || PRECONFIGURED_ANALYSES['college-commit-enrollment'];

  const handleSelectRepository = (repo: RepositorySummary) => {
    setSelectedRepo(repo);
    const firstCommit = repo.commits[0];
    if (firstCommit && PRECONFIGURED_ANALYSES[firstCommit.analysisKey]) {
      setSelectedCommitKey(firstCommit.analysisKey);
    }
  };

  const handleSelectCommitAndAnalyze = (repo: RepositorySummary, commitSha: string) => {
    setSelectedRepo(repo);
    const commit = repo.commits.find(c => c.sha === commitSha) || repo.commits[0];
    if (commit && PRECONFIGURED_ANALYSES[commit.analysisKey]) {
      setSelectedCommitKey(commit.analysisKey);
    }
    triggerAnalyzeFlow();
  };

  const triggerAnalyzeFlow = () => {
    setIsAnalyzing(true);
    setActiveTab('WORKSPACE');
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 600);
  };

  const handleRecordDecision = (status: any, rationale: string) => {
    console.log(`[DECISION_LOG] Status: ${status}, Rationale: ${rationale}`);
  };

  const handleNewRepoImported = (newRepo: RepositorySummary) => {
    DEMO_REPOSITORIES.unshift(newRepo);
    handleSelectRepository(newRepo);
    setActiveTab('WORKSPACE');
  };

  return (
    <div className="flex h-screen w-screen bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* 1. Left Navigation Rail */}
      <aside className="w-56 border-r border-slate-800 bg-slate-900 flex flex-col justify-between shrink-0 select-none z-20">
        <div>
          {/* Brand Logo & Title */}
          <div className="p-4 border-b border-slate-800 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center shadow-indigo-500/20 shadow-lg">
              <Network className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-xs font-bold text-slate-100 tracking-wide uppercase">
                AI Change-Risk Graph
              </h1>
              <span className="text-[10px] font-mono text-indigo-400">
                v2.1.0 • Release Intel
              </span>
            </div>
          </div>

          {/* Repository Selector Dropdown */}
          <div className="p-3 border-b border-slate-800 bg-slate-950/40">
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                Active Repository
              </label>
              <button 
                onClick={() => setActiveTab('REPOSITORIES')}
                className="text-[10px] font-mono text-indigo-400 hover:text-indigo-300"
              >
                Browse All
              </button>
            </div>
            <select
              value={selectedRepo.id}
              onChange={(e) => {
                const found = DEMO_REPOSITORIES.find(r => r.id === e.target.value);
                if (found) handleSelectRepository(found);
              }}
              className="w-full bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded p-1.5 focus:outline-hidden focus:border-indigo-500 font-sans truncate mb-2"
            >
              {DEMO_REPOSITORIES.map(r => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>

            {/* Commit Selector for Active Repo */}
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
              Target Commit
            </label>
            <select
              value={selectedCommitKey}
              onChange={(e) => setSelectedCommitKey(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded p-1.5 focus:outline-hidden focus:border-indigo-500 font-mono truncate mb-2.5"
            >
              {selectedRepo.commits.map(c => (
                <option key={c.sha} value={c.analysisKey}>
                  {c.sha.substring(0, 7)}: {c.message.substring(0, 24)}...
                </option>
              ))}
            </select>

            {/* Execute Analysis Action Button */}
            <button
              onClick={triggerAnalyzeFlow}
              disabled={isAnalyzing}
              className="w-full py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Traversing Graph...</span>
                </>
              ) : (
                <>
                  <Zap className="w-3.5 h-3.5" />
                  <span>Analyze Change</span>
                </>
              )}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-2 space-y-1 text-xs">
            <button
              onClick={() => setActiveTab('REPOSITORIES')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'REPOSITORIES'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <FolderGit2 className="w-4 h-4" />
              <span>Repositories Registry</span>
            </button>

            <button
              onClick={() => setActiveTab('WORKSPACE')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'WORKSPACE'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Network className="w-4 h-4" />
              <span>Change & Graph Analysis</span>
            </button>

            <button
              onClick={() => setActiveTab('TESTS')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'TESTS'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span>Prioritized Tests</span>
            </button>

            <button
              onClick={() => setActiveTab('WHAT_IF')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'WHAT_IF'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>What-If Release</span>
            </button>

            <button
              onClick={() => setActiveTab('RESEARCH')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'RESEARCH'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              <span>Model & Research Eval</span>
            </button>

            <button
              onClick={() => setActiveTab('HISTORY')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'HISTORY'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <History className="w-4 h-4" />
              <span>History & Outcomes</span>
            </button>

            <button
              onClick={() => setActiveTab('SECURITY')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'SECURITY'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Security & Leakage Gate</span>
            </button>
          </nav>
        </div>

        {/* Footer info & ZIP Download */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-500 font-mono space-y-2">
          <a
            href="/ai-change-risk-graph-capstone.zip"
            download="ai-change-risk-graph-capstone.zip"
            className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-indigo-600/90 hover:bg-indigo-600 text-white font-sans text-xs font-semibold shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Project ZIP</span>
          </a>
          <div>
            <div className="flex items-center gap-1.5 text-emerald-400 mb-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>T₀ Barrier Enforced</span>
            </div>
            <div>Mode: Repository-Agnostic</div>
          </div>
        </div>
      </aside>

      {/* 2. Main Content Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Header Bar */}
        <header className="h-14 border-b border-slate-800 bg-slate-900/90 px-6 flex items-center justify-between z-10 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono bg-indigo-950 text-indigo-300 px-2.5 py-1 rounded border border-indigo-800/70 font-semibold flex items-center gap-1.5">
              <FolderGit2 className="w-3.5 h-3.5" />
              {selectedRepo.name}
            </span>
            <span className="text-xs text-slate-400 hidden sm:inline">
              Branch: <strong className="text-slate-200 font-mono">{selectedRepo.branch}</strong>
            </span>
            <span className="text-xs text-slate-400 hidden md:inline">
              Category: <span className="text-indigo-400">{selectedRepo.category}</span>
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5 text-slate-400 font-mono bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Commit: {currentAnalysis.commitSha.substring(0, 7)}</span>
            </div>

            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <div className="w-6 h-6 rounded-full bg-indigo-900 border border-indigo-500/50 flex items-center justify-center text-xs font-semibold text-indigo-200">
                RE
              </div>
              <span className="text-slate-300 text-xs hidden sm:inline">Release Engineer</span>
            </div>
          </div>
        </header>

        {/* Dynamic Main Workspace according to Tab */}
        <main className="flex-1 overflow-hidden relative">
          {activeTab === 'REPOSITORIES' && (
            <RepositoryExplorerView 
              selectedRepository={selectedRepo}
              onSelectRepository={handleSelectRepository}
              onSelectCommitAndAnalyze={handleSelectCommitAndAnalyze}
              onOpenImportModal={() => setIsImportModalOpen(true)}
            />
          )}

          {activeTab === 'WORKSPACE' && (
            <div className="h-full w-full grid grid-cols-12 overflow-hidden">
              {/* Left Column: 20% (col-span-3) Change Summary */}
              <div className="col-span-3 border-r border-slate-800 bg-slate-950 overflow-hidden h-full">
                <ChangeSummaryPanel analysis={currentAnalysis} />
              </div>

              {/* Center Column: 55% (col-span-6) Interactive Risk Graph Canvas */}
              <div className="col-span-6 bg-slate-950 overflow-hidden h-full relative">
                <GraphCanvas 
                  graph={currentAnalysis.graph} 
                  selectedNode={selectedNode}
                  onSelectNode={setSelectedNode}
                />
              </div>

              {/* Right Column: 25% (col-span-3) Risk, Evidence & AI Explanation */}
              <div className="col-span-3 border-l border-slate-800 bg-slate-950 overflow-hidden h-full">
                <RiskEvidencePanel 
                  analysis={currentAnalysis}
                  selectedNode={selectedNode}
                  onClearSelectedNode={() => setSelectedNode(null)}
                  onSelectEvidence={(evId) => console.log('Selected evidence:', evId)}
                />
              </div>
            </div>
          )}

          {activeTab === 'TESTS' && (
            <TestRecommendationTable analysis={currentAnalysis} />
          )}

          {activeTab === 'WHAT_IF' && (
            <WhatIfReleaseView 
              analysis={currentAnalysis} 
              onRecordDecision={handleRecordDecision} 
            />
          )}

          {activeTab === 'RESEARCH' && (
            <ResearchEvaluationView />
          )}

          {activeTab === 'HISTORY' && (
            <HistoryFeedbackView 
              onSelectAnalysis={(key) => {
                setSelectedCommitKey(key);
                setActiveTab('WORKSPACE');
              }} 
            />
          )}

          {activeTab === 'SECURITY' && (
            <SecurityAuditView />
          )}
        </main>
      </div>

      {/* Import Repository Modal */}
      <ImportRepositoryModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportSuccess={handleNewRepoImported}
      />
    </div>
  );
};
