import React, { useState } from 'react';
import { 
  History, 
  GitCommit, 
  AlertCircle, 
  CheckCircle2, 
  RotateCcw, 
  Clock, 
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  TrendingDown,
  TrendingUp
} from 'lucide-react';
import { PRECONFIGURED_ANALYSES } from '../../mockData.ts';
import { AnalysisResult } from '../../types.ts';

interface HistoryFeedbackViewProps {
  onSelectAnalysis: (key: string) => void;
}

export const HistoryFeedbackView: React.FC<HistoryFeedbackViewProps> = ({ onSelectAnalysis }) => {
  const [activeTab, setActiveTab] = useState<'RECORDS' | 'TIMELINE'>('RECORDS');

  const historyItems = [
    {
      commitSha: 'c891a45e21',
      changeId: '#COL-124',
      service: 'CampusOS Student Service',
      summary: 'feat(enrollment): validate student prerequisite GPA and bursar clearance',
      riskScore: 78,
      riskLevel: 'HIGH',
      t0Timestamp: '2026-09-17T09:00:00Z',
      decision: 'RELEASE_WITH_MITIGATION (Canary 10%)',
      actualOutcome: {
        deploymentStatus: 'SUCCESS',
        incidentOccurred: false,
        latencyDelta: '+0.4%',
        errorRateDelta: '0.0%',
        testsExecuted: 12,
        suiteSavings: '81.25%'
      },
      key: 'college-commit-enrollment'
    },
    {
      commitSha: 'b882f019c4',
      changeId: '#BNK-902',
      service: 'Banking Wire Service',
      summary: 'security(aml): update high-value wire validation thresholds & OFAC checks',
      riskScore: 92,
      riskLevel: 'CRITICAL',
      t0Timestamp: '2026-09-17T08:45:00Z',
      decision: 'RELEASE_WITH_MITIGATION (Multi-Sign Canary)',
      actualOutcome: {
        deploymentStatus: 'SUCCESS',
        incidentOccurred: false,
        latencyDelta: '+0.2%',
        errorRateDelta: '0.0%',
        testsExecuted: 18,
        suiteSavings: '88.5%'
      },
      key: 'banking-commit-aml'
    },
    {
      commitSha: 'c452f89a91',
      changeId: '#452',
      service: 'Payment Service',
      summary: 'refactor(payment): calculateTotal() precision & VAT calculation',
      riskScore: 87,
      riskLevel: 'HIGH',
      t0Timestamp: '2026-09-17T09:00:00Z',
      decision: 'RELEASE_WITH_MITIGATION (Canary 10%)',
      actualOutcome: {
        deploymentStatus: 'SUCCESS',
        incidentOccurred: false,
        latencyDelta: '+1.2%',
        errorRateDelta: '-0.1%',
        testsExecuted: 5,
        suiteSavings: '98.7%'
      },
      key: 'commit-452-high-risk'
    },
    {
      commitSha: 'a301d4187e',
      changeId: '#301',
      service: 'Documentation',
      summary: 'docs(readme): update notification queue delivery architecture',
      riskScore: 12,
      riskLevel: 'LOW',
      t0Timestamp: '2026-09-17T08:30:00Z',
      decision: 'RELEASE (Direct Merge)',
      actualOutcome: {
        deploymentStatus: 'SUCCESS',
        incidentOccurred: false,
        latencyDelta: '0.0%',
        errorRateDelta: '0.0%',
        testsExecuted: 1,
        suiteSavings: '99.7%'
      },
      key: 'commit-301-low-risk'
    },
    {
      commitSha: 'b443e11029',
      changeId: '#443',
      service: 'Kafka Events Queue',
      summary: 'feat(queue): partition key rebalancing for order streaming',
      riskScore: 78,
      riskLevel: 'HIGH',
      t0Timestamp: '2026-08-28T16:15:00Z',
      decision: 'RELEASE (Direct)',
      actualOutcome: {
        deploymentStatus: 'ROLLED_BACK',
        incidentOccurred: true,
        incidentRef: 'INC-102',
        latencyDelta: '+64.0%',
        errorRateDelta: '+4.2%',
        testsExecuted: 12,
        suiteSavings: '96.8%'
      },
      key: 'commit-452-high-risk'
    }
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6 border-b border-slate-800 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <History className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-semibold text-slate-100">
                Analysis History & Outcome Feedback Loop
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Audit trail connecting prediction-time assessments ($T_0$) with post-deployment outcomes and ground truth validation.
            </p>
          </div>
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setActiveTab('RECORDS')}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                activeTab === 'RECORDS' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Outcome Table
            </button>
            <button
              onClick={() => setActiveTab('TIMELINE')}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                activeTab === 'TIMELINE' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Causal Timeline
            </button>
          </div>
        </div>
      </div>

      {/* Main Historical Table */}
      {activeTab === 'RECORDS' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase tracking-wider">
                  <th className="py-2.5 px-3">Commit & Scope</th>
                  <th className="py-2.5 px-3">T₀ Cutoff Time</th>
                  <th className="py-2.5 px-3">Predicted Risk</th>
                  <th className="py-2.5 px-3">Human Decision</th>
                  <th className="py-2.5 px-3">Actual Outcome</th>
                  <th className="py-2.5 px-3 text-right">Test Reduction</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {historyItems.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-mono font-semibold text-slate-200 flex items-center gap-1.5">
                        <GitCommit className="w-3.5 h-3.5 text-indigo-400" />
                        {item.changeId} ({item.commitSha.substring(0, 7)})
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{item.summary}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400 text-[11px]">
                      {new Date(item.t0Timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                        item.riskLevel === 'HIGH' 
                          ? 'bg-amber-950 text-amber-300 border-amber-800' 
                          : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      }`}>
                        {item.riskScore}/100 {item.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-xs text-slate-300 font-medium">
                      {item.decision}
                    </td>
                    <td className="py-3 px-3">
                      {item.actualOutcome.deploymentStatus === 'ROLLED_BACK' ? (
                        <div className="flex items-center gap-1.5 text-red-400 font-semibold text-xs">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>Rolled Back ({item.actualOutcome.incidentRef})</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Success (Stable)</span>
                        </div>
                      )}
                      <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                        Latency: {item.actualOutcome.latencyDelta} • Errors: {item.actualOutcome.errorRateDelta}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-emerald-400 font-bold">
                      {item.actualOutcome.suiteSavings}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onSelectAnalysis(item.key)}
                        className="text-xs font-medium text-indigo-400 hover:text-indigo-300 px-2 py-1 bg-indigo-950/60 hover:bg-indigo-900/60 rounded border border-indigo-800/60 transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Causal Timeline View */
        <div className="space-y-4 max-w-2xl mx-auto py-2">
          {historyItems.map((item, idx) => (
            <div key={idx} className="relative pl-6 border-l-2 border-indigo-500/40 pb-6 last:pb-0">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-950 border-2 border-indigo-500 flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-mono text-indigo-400 font-bold">{item.changeId} — {item.service}</span>
                  <span className="text-slate-500 font-mono">{new Date(item.t0Timestamp).toUTCString()}</span>
                </div>
                <div className="font-medium text-slate-200 text-sm mb-2">{item.summary}</div>
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-2.5 rounded border border-slate-800/80 mb-2">
                  <div>Predicted Risk: <strong className="text-slate-200 font-mono">{item.riskScore}/100</strong></div>
                  <div>Outcome: <strong className={item.actualOutcome.deploymentStatus === 'SUCCESS' ? 'text-emerald-400' : 'text-red-400'}>{item.actualOutcome.deploymentStatus}</strong></div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Mitigation applied: <span className="text-slate-300 font-medium">{item.decision}</span>. Selected regression tests confirmed zero regressions on verified downstream pathways.
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Closed-Loop Continuous Feedback Note */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 leading-relaxed mt-auto">
        <span className="font-semibold text-slate-200 block mb-1">
          Feedback Learning Architecture (Phase 17)
        </span>
        <p>
          Once an actual deployment outcome is observed (post-release telemetry, test results, or rollback incidents), it is stored as an immutable ground-truth event. The temporal engine allows this newly minted history to inform future predictions for subsequent changes without retrospectively contaminating past evaluation sets.
        </p>
      </div>
    </div>
  );
};
