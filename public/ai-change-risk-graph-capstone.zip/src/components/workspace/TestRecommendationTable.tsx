import React, { useState } from 'react';
import { 
  CheckSquare, 
  Play, 
  Clock, 
  ShieldCheck, 
  AlertCircle, 
  Percent, 
  Layers,
  ArrowRight,
  Filter
} from 'lucide-react';
import { RecommendedTest, AnalysisResult } from '../../types.ts';

interface TestRecommendationTableProps {
  analysis: AnalysisResult;
}

export const TestRecommendationTable: React.FC<TestRecommendationTableProps> = ({ analysis }) => {
  const { recommendedTests, testMetrics } = analysis;
  const [selectedTests, setSelectedTests] = useState<string[]>(
    recommendedTests.filter(t => t.priority === 'P0' || t.priority === 'P1').map(t => t.id)
  );
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'P0' | 'P1' | 'P2'>('ALL');
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testRunCompleted, setTestRunCompleted] = useState(false);

  const toggleSelectTest = (id: string) => {
    setSelectedTests(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedTests.length === recommendedTests.length) {
      setSelectedTests([]);
    } else {
      setSelectedTests(recommendedTests.map(t => t.id));
    }
  };

  const handleExecuteTests = () => {
    setIsRunningTests(true);
    setTestRunCompleted(false);
    setTimeout(() => {
      setIsRunningTests(false);
      setTestRunCompleted(true);
    }, 1800);
  };

  const filteredTests = recommendedTests.filter(t => {
    if (activeFilter === 'ALL') return true;
    return t.priority === activeFilter;
  });

  const getPriorityBadge = (priority: 'P0' | 'P1' | 'P2') => {
    switch (priority) {
      case 'P0':
        return 'bg-red-950/80 text-red-300 border-red-800 font-bold';
      case 'P1':
        return 'bg-amber-950/80 text-amber-300 border-amber-800 font-semibold';
      case 'P2':
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200">
      {/* Metrics Banner */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-6 py-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-indigo-400" />
              Impact-Aware Test Prioritization
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Targeted regression testing based on structural reach and runtime risk patterns.
            </p>
          </div>

          {/* Key Objective Metrics */}
          <div className="flex items-center gap-6 text-sm">
            <div className="flex flex-col">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Test Suite Reduction</span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-lg font-mono font-bold text-emerald-400">
                  {testMetrics.testReductionPercent}%
                </span>
                <span className="text-xs text-slate-500">
                  ({testMetrics.selectedCount} / {testMetrics.totalSuiteCount})
                </span>
              </div>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div className="flex flex-col">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Failure Detection Retained</span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-lg font-mono font-bold text-indigo-400">
                  {testMetrics.projectedFailureDetectionRetained}%
                </span>
                <span className="text-xs text-slate-500">proven in benchmark</span>
              </div>
            </div>

            <div className="h-8 w-px bg-slate-800" />

            <div className="flex flex-col">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Estimated CI Time Saved</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-lg font-mono font-bold text-slate-200">
                  ~{testMetrics.estimatedTimeSavedSeconds}s
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action bar */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-800/80">
          <div className="flex items-center gap-2">
            <button
              onClick={handleSelectAll}
              className="text-xs text-slate-300 hover:text-white px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              {selectedTests.length === recommendedTests.length ? 'Deselect All' : 'Select All Recommended'}
            </button>
            <div className="h-4 w-px bg-slate-800 mx-1" />
            <div className="flex items-center gap-1 text-xs">
              {(['ALL', 'P0', 'P1', 'P2'] as const).map(filter => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-2 py-0.5 rounded text-[11px] ${
                    activeFilter === filter 
                      ? 'bg-indigo-600 text-white font-medium' 
                      : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {testRunCompleted && (
              <span className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium animate-in fade-in">
                <ShieldCheck className="w-4 h-4" />
                Selected tests passed ({selectedTests.length} tests)
              </span>
            )}
            <button
              onClick={handleExecuteTests}
              disabled={isRunningTests || selectedTests.length === 0}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold shadow-xs transition-all ${
                isRunningTests || selectedTests.length === 0
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white'
              }`}
            >
              <Play className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : 'fill-current'}`} />
              <span>{isRunningTests ? 'Executing CI Suite...' : `Run ${selectedTests.length} Selected Tests`}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Table of Recommended Tests */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase tracking-wider">
              <th className="py-2.5 px-3 w-10">Sel</th>
              <th className="py-2.5 px-3 w-20">Priority</th>
              <th className="py-2.5 px-3">Test Name & Suite</th>
              <th className="py-2.5 px-3">Mapped Entity / Rationale</th>
              <th className="py-2.5 px-3 w-24 text-right">Est. Duration</th>
              <th className="py-2.5 px-3 w-28 text-right">Failure Corr.</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {filteredTests.map((test) => {
              const isSelected = selectedTests.includes(test.id);
              return (
                <tr 
                  key={test.id}
                  className={`hover:bg-slate-900/50 transition-colors ${isSelected ? 'bg-slate-900/30' : 'opacity-70'}`}
                >
                  <td className="py-3 px-3">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelectTest(test.id)}
                      className="rounded bg-slate-900 border-slate-700 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                  </td>
                  <td className="py-3 px-3">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] border font-mono ${getPriorityBadge(test.priority)}`}>
                      {test.priority}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono">
                    <div className="font-semibold text-slate-200 text-xs">{test.name}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{test.suite} • {test.type}</div>
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    <div>{test.reason}</div>
                    <div className="flex items-center gap-1.5 mt-1">
                      {test.mappedComponentIds.map(cid => (
                        <span key={cid} className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800/80 text-slate-400">
                          {cid}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-400">
                    {(test.estimatedDurationMs / 1000).toFixed(1)}s
                  </td>
                  <td className="py-3 px-3 text-right font-mono">
                    {test.historicalFailureCorrelation ? (
                      <span className="text-amber-400 font-semibold">
                        {(test.historicalFailureCorrelation * 100).toFixed(0)}%
                      </span>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
