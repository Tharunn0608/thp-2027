import React, { useState } from 'react';
import { 
  GitBranch, 
  ShieldCheck, 
  AlertTriangle, 
  Sliders, 
  CheckCircle, 
  ArrowRight,
  TrendingDown,
  Info
} from 'lucide-react';
import { WhatIfScenario, AnalysisResult } from '../../types.ts';

interface WhatIfReleaseViewProps {
  analysis: AnalysisResult;
  onRecordDecision: (status: 'RELEASE' | 'RELEASE_WITH_MITIGATION' | 'TEST_MORE' | 'DELAY', rationale: string) => void;
}

export const WhatIfReleaseView: React.FC<WhatIfReleaseViewProps> = ({ analysis, onRecordDecision }) => {
  const { whatIfScenarios, risk } = analysis;
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(whatIfScenarios[0]?.id || '');
  const [decisionRationale, setDecisionRationale] = useState<string>('');
  const [decisionSubmitted, setDecisionSubmitted] = useState<boolean>(false);

  const activeScenario = whatIfScenarios.find(s => s.id === selectedScenarioId) || whatIfScenarios[0];

  const handleDecisionSubmit = (status: 'RELEASE' | 'RELEASE_WITH_MITIGATION' | 'TEST_MORE' | 'DELAY') => {
    onRecordDecision(status, decisionRationale || `Decision executed under ${activeScenario?.name || 'standard'} strategy.`);
    setDecisionSubmitted(true);
  };

  const getExposureBadge = (exposure: WhatIfScenario['estimatedExposure']) => {
    switch (exposure) {
      case 'HIGH':
        return 'bg-red-950 text-red-300 border-red-800';
      case 'CONTROLLED':
        return 'bg-amber-950 text-amber-300 border-amber-800';
      case 'LOW':
        return 'bg-emerald-950 text-emerald-300 border-emerald-800';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Sliders className="w-5 h-5 text-indigo-400" />
          <h2 className="text-base font-semibold text-slate-100">
            What-If Release Mitigation & Decision Support
          </h2>
        </div>
        <p className="text-xs text-slate-400">
          Compare estimated exposure across controlled release strategies. What-If calculations provide decision support, not guaranteed production outcomes.
        </p>
      </div>

      {/* Scenario Selection Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {whatIfScenarios.map((scenario) => {
          const isSelected = scenario.id === selectedScenarioId;
          const riskDelta = scenario.estimatedRiskScore - risk.score;

          return (
            <div
              key={scenario.id}
              onClick={() => setSelectedScenarioId(scenario.id)}
              className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                isSelected 
                  ? 'bg-indigo-950/30 border-indigo-500 shadow-md ring-1 ring-indigo-500/50' 
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="font-semibold text-sm text-slate-100">{scenario.name}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${getExposureBadge(scenario.estimatedExposure)}`}>
                    {scenario.estimatedExposure}
                  </span>
                </div>
                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  {scenario.description}
                </p>
              </div>

              <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Estimated Risk</div>
                  <div className="text-base font-mono font-bold text-slate-200">
                    {scenario.estimatedRiskScore} / 100
                  </div>
                </div>

                {riskDelta < 0 && (
                  <div className="flex items-center gap-1 text-emerald-400 text-xs font-semibold bg-emerald-950/60 px-2 py-1 rounded border border-emerald-800/60">
                    <TrendingDown className="w-3.5 h-3.5" />
                    <span>{riskDelta} pts</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Scenario Detailed Deep Dive */}
      {activeScenario && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-400" />
              Scenario Analysis: {activeScenario.name}
            </h3>
            <span className="text-xs font-mono text-slate-500">Residual Risk: {activeScenario.residualRisk}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
              <span className="font-semibold text-slate-300 block mb-1.5 uppercase text-[11px] tracking-wider">
                Key Operational Assumptions
              </span>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                {activeScenario.assumptions.map((ass, i) => (
                  <li key={i}>{ass}</li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
              <span className="font-semibold text-slate-300 block mb-1.5 uppercase text-[11px] tracking-wider">
                Recommended Mitigations
              </span>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                {activeScenario.recommendedActions.map((act, i) => (
                  <li key={i}>{act}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Human Release Decision Gate Box */}
      <div className="bg-slate-900 border border-indigo-500/40 rounded-xl p-5 mt-auto">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              Human Release Engineering Decision Gate
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Current Commit: <span className="font-mono text-slate-200">{analysis.commitSha.substring(0, 7)} ({analysis.risk.level} Risk: {analysis.risk.score}/100)</span>
          </span>
        </div>
        <p className="text-xs text-slate-400 mb-3">
          The system provides decision intelligence; the release decision remains strictly human-governed.
        </p>

        <div className="mb-4">
          <input
            type="text"
            value={decisionRationale}
            onChange={(e) => setDecisionRationale(e.target.value)}
            placeholder="Document release rationale, mitigation conditions, or review approvals..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-hidden focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDecisionSubmit('RELEASE_WITH_MITIGATION')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              Approve with Mitigation (Canary 10%)
            </button>
            <button
              onClick={() => handleDecisionSubmit('TEST_MORE')}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors"
            >
              Request Additional P0 Tests
            </button>
            <button
              onClick={() => handleDecisionSubmit('DELAY')}
              className="px-3.5 py-2 bg-red-950/60 hover:bg-red-900/60 border border-red-800 text-red-300 rounded-lg text-xs font-medium transition-colors"
            >
              Delay / Reject Release
            </button>
          </div>

          {decisionSubmitted && (
            <span className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium animate-in fade-in">
              <CheckCircle className="w-4 h-4" />
              Decision recorded in immutable audit log.
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
