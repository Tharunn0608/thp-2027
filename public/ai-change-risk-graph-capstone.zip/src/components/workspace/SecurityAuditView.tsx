import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Clock, 
  FileCheck2, 
  AlertOctagon, 
  Play, 
  CheckCircle2, 
  XCircle,
  Database,
  Lock,
  Search,
  Key
} from 'lucide-react';
import { TemporalLeakageAuditor } from '../../graph/temporal_auditor.ts';

export const SecurityAuditView: React.FC = () => {
  const [testResults, setTestResults] = useState<{ testName: string; passed: boolean; message: string }[]>(
    TemporalLeakageAuditor.runAutomatedLeakageSuite()
  );
  const [isRunning, setIsRunning] = useState(false);

  const handleRerunSuite = () => {
    setIsRunning(true);
    setTimeout(() => {
      setTestResults(TemporalLeakageAuditor.runAutomatedLeakageSuite());
      setIsRunning(false);
    }, 600);
  };

  const securityControls = [
    {
      domain: 'Temporal Leakage Prevention',
      status: 'ENFORCED',
      control: 'T0 Point-in-Time Wall',
      description: 'Strict logical gate excluding telemetry windows, incidents, and graph edge additions occurring after prediction timestamp T0.'
    },
    {
      domain: 'LLM Prompt-Injection Boundary',
      status: 'ENFORCED',
      control: 'Read-Only Evidence Sanitizer',
      description: 'The explanation service passes sanitized JSON payloads containing pre-extracted evidence IDs only. User commits cannot override risk scoring.'
    },
    {
      domain: 'Data Integrity & Ground Truth Separation',
      status: 'ENFORCED',
      control: 'Prediction vs. Outcome Isolation',
      description: 'Pre-T0 predictions and post-T0 deployment outcomes are persisted in disjoint data models to preserve unbiased empirical evaluation.'
    },
    {
      domain: 'Role-Based Access Control (RBAC)',
      status: 'ACTIVE',
      control: 'Least-Privilege Authorization',
      description: 'Separate permissions for Release Engineers (decision authority), Developers (submission), and Researchers (metrics export).'
    },
    {
      domain: 'SSRF & Repository Ingestion Defense',
      status: 'PROTECTED',
      control: 'URL & Scheme Allowlisting',
      description: 'Outbound fetch restrictions blocking AWS/GCP metadata endpoints (169.254.169.254) and internal subnet traversal.'
    }
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6 border-b border-slate-800 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-semibold text-slate-100">
                Security, RBAC & Temporal Leakage Certification Gate
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Automated validation of research validity, prompt injection protections, and strict point-in-time ($T_0$) isolation.
            </p>
          </div>

          <button
            onClick={handleRerunSuite}
            disabled={isRunning}
            className="flex items-center gap-2 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium shadow-xs transition-colors"
          >
            <Play className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>Run P0 Leakage Gate Checks</span>
          </button>
        </div>
      </div>

      {/* P0 Temporal Leakage Test Suite Results */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-indigo-400" />
            Automated P0 Temporal Leakage Suite
          </span>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
            {testResults.filter(t => t.passed).length} / {testResults.length} Checks Passing
          </span>
        </div>

        <div className="space-y-2.5">
          {testResults.map((t, idx) => (
            <div 
              key={idx}
              className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-start justify-between gap-3 text-xs"
            >
              <div className="flex items-start gap-2.5">
                {t.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-semibold text-slate-200">{t.testName}</div>
                  <div className="text-slate-400 mt-0.5 leading-relaxed">{t.message}</div>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                t.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-red-950 text-red-300 border border-red-800'
              }`}>
                {t.passed ? 'PASS' : 'FAIL'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Security Architecture & Governance Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-3">
          Security Controls & Threat Boundary Verification
        </span>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {securityControls.map((sc, i) => (
            <div key={i} className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="font-mono text-indigo-400 font-semibold text-[11px] uppercase tracking-wider">
                    {sc.domain}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300">
                    {sc.status}
                  </span>
                </div>
                <div className="font-semibold text-slate-100 mb-1">{sc.control}</div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  {sc.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audit & Compliance Declaration */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 leading-relaxed mt-auto">
        <span className="font-semibold text-slate-200 block mb-1">
          Security Principle Compliance (Section 40)
        </span>
        <p>
          Security controls safeguard system confidentiality and integrity without violating temporal correctness, provenance, or reproducibility. Sensitive source code snippets are minimized, external LLM calls transmit only sanitized structured metadata, and all decision events are immutably logged with actor identities.
        </p>
      </div>
    </div>
  );
};
