import React from 'react';
import { 
  GitCommit, 
  GitBranch, 
  ShieldAlert, 
  Network, 
  CheckCircle2, 
  Clock, 
  Database, 
  Server, 
  FileCode, 
  Radio, 
  Activity, 
  Flame, 
  AlertTriangle 
} from 'lucide-react';
import { AnalysisResult } from '../../types.ts';

interface ChangeSummaryProps {
  analysis: AnalysisResult;
}

export const ChangeSummaryPanel: React.FC<ChangeSummaryProps> = ({ analysis }) => {
  const { changeSummary, predictionTimeT0, commitSha, baseSha, risk, blastRadius } = analysis;

  const getRiskBadgeColor = (level: string) => {
    switch (level) {
      case 'CRITICAL':
        return 'bg-red-950 text-red-300 border-red-800';
      case 'HIGH':
        return 'bg-amber-950 text-amber-300 border-amber-800';
      case 'MEDIUM':
        return 'bg-yellow-950 text-yellow-300 border-yellow-800';
      default:
        return 'bg-emerald-950 text-emerald-300 border-emerald-800';
    }
  };

  return (
    <div className="flex flex-col gap-4 p-4 text-slate-200 text-sm overflow-y-auto h-full">
      {/* Header Info */}
      <div className="border-b border-slate-800 pb-3">
        <div className="flex items-center justify-between gap-2 mb-1">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <GitCommit className="w-3.5 h-3.5 text-indigo-400" />
            Commit {commitSha.substring(0, 7)}
          </span>
          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${getRiskBadgeColor(risk.level)}`}>
            {risk.level} RISK
          </span>
        </div>
        <p className="font-medium text-slate-100 leading-snug line-clamp-2">
          {changeSummary.message}
        </p>
        <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
          <span>{changeSummary.author}</span>
          <span>•</span>
          <span className="font-mono text-[11px] text-slate-500">Base: {baseSha?.substring(0, 7) || 'HEAD~1'}</span>
        </div>
      </div>

      {/* T0 Temporal Barrier Indicator */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3">
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold mb-1">
          <Clock className="w-4 h-4" />
          <span>Point-in-Time T₀ Context</span>
        </div>
        <p className="text-xs text-slate-400 font-mono">
          {new Date(predictionTimeT0).toUTCString()}
        </p>
        <div className="mt-2 text-[11px] text-slate-400 border-t border-slate-800/80 pt-1.5 flex items-center gap-1">
          <ShieldAlert className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Post-T₀ incident and telemetry strictly sealed from features.</span>
        </div>
      </div>

      {/* Diff Metrics */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-slate-900 border border-slate-800 rounded p-2">
          <div className="text-xs text-slate-400">Files</div>
          <div className="font-mono font-semibold text-slate-200 mt-0.5">{changeSummary.filesChanged}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded p-2">
          <div className="text-xs text-emerald-400">+{changeSummary.insertions}</div>
          <div className="text-[10px] text-slate-500">Insertions</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded p-2">
          <div className="text-xs text-red-400">-{changeSummary.deletions}</div>
          <div className="text-[10px] text-slate-500">Deletions</div>
        </div>
      </div>

      {/* Changed Entities Breakdown */}
      <div>
        <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>Changed Entities</span>
          <span className="text-slate-500 font-normal">({changeSummary.entities.length})</span>
        </div>
        <div className="flex flex-col gap-2">
          {changeSummary.entities.map((entity) => (
            <div 
              key={entity.id}
              className="bg-slate-900/60 border border-slate-800 hover:border-slate-700 rounded-lg p-2.5 transition-colors"
            >
              <div className="flex items-start justify-between gap-1.5 mb-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <FileCode className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="font-mono text-xs font-medium text-slate-200 truncate">
                    {entity.name}
                  </span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded shrink-0">
                  {entity.type}
                </span>
              </div>
              <div className="text-[11px] font-mono text-slate-500 truncate mb-1">
                {entity.path}
              </div>
              <p className="text-xs text-slate-400 line-clamp-2">
                {entity.diffSummary}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Blast Radius Quick Summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 mt-auto">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            Blast Radius Reach
          </span>
          <span className="font-mono font-bold text-amber-400">{blastRadius.score}/100</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 mb-2">
          <div>Direct nodes: <span className="font-mono font-semibold text-slate-200">{blastRadius.directCount}</span></div>
          <div>Indirect: <span className="font-mono font-semibold text-slate-200">{blastRadius.indirectCount}</span></div>
          <div>Critical tier: <span className="font-mono font-semibold text-red-400">{blastRadius.criticalCount}</span></div>
          <div>Depth: <span className="font-mono font-semibold text-slate-200">{blastRadius.maxDepth} hops</span></div>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-800/80 pt-2">
          {blastRadius.summary}
        </p>
      </div>
    </div>
  );
};
