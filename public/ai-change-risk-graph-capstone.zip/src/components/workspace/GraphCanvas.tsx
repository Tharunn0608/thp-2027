import React, { useState } from 'react';
import { 
  Network, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Eye, 
  Filter, 
  Activity, 
  History, 
  Server, 
  Database, 
  Radio, 
  Terminal,
  ShieldCheck,
  AlertOctagon
} from 'lucide-react';
import { SoftwareGraph, GraphNode, GraphEdge } from '../../types.ts';

interface GraphCanvasProps {
  graph: SoftwareGraph;
  onSelectNode: (node: GraphNode | null) => void;
  selectedNode: GraphNode | null;
}

export const GraphCanvas: React.FC<GraphCanvasProps> = ({ graph, onSelectNode, selectedNode }) => {
  const [filterLayer, setFilterLayer] = useState<string>('ALL');
  const [showRuntimeOnly, setShowRuntimeOnly] = useState<boolean>(false);
  const [showAffectedOnly, setShowAffectedOnly] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Dynamic topological layout algorithm that works for ANY repository
  const getNodeCoordinates = (nodeId: string, index: number, total: number) => {
    // Known curated positions for crisp rendering
    const customPositions: Record<string, { x: number; y: number }> = {
      // E-Commerce
      'srv-gateway': { x: 80, y: 160 },
      'api-checkout': { x: 220, y: 160 },
      'srv-order': { x: 380, y: 160 },
      'fn-order-calc': { x: 380, y: 260 },
      'db-order': { x: 380, y: 60 },
      'srv-payment': { x: 560, y: 260 },
      'fn-calc-total': { x: 560, y: 360 },
      'db-payment': { x: 740, y: 360 },
      'ext-stripe': { x: 740, y: 240 },
      'queue-events': { x: 560, y: 80 },
      'srv-notification': { x: 740, y: 80 },
      'srv-inventory': { x: 380, y: 360 },
      'db-inventory': { x: 220, y: 360 },
      // College Management System
      'col-gw': { x: 90, y: 180 },
      'col-api-enroll': { x: 240, y: 180 },
      'col-srv-student': { x: 400, y: 180 },
      'col-fn-enroll': { x: 400, y: 300 },
      'col-db-course': { x: 400, y: 60 },
      'col-srv-fees': { x: 580, y: 300 },
      'col-fn-dues': { x: 740, y: 340 },
      'col-queue-alerts': { x: 580, y: 180 },
      'col-srv-notify': { x: 740, y: 180 },
      'col-ext-sis': { x: 580, y: 60 },
      'col-db-audit': { x: 240, y: 320 },
      'col-srv-exam': { x: 740, y: 60 },
      // Banking Core & Wire Ledger
      'bnk-gw': { x: 90, y: 180 },
      'bnk-api-wire': { x: 240, y: 180 },
      'bnk-srv-auth': { x: 240, y: 60 },
      'bnk-srv-wire': { x: 420, y: 180 },
      'bnk-fn-validate': { x: 420, y: 300 },
      'bnk-srv-ledger': { x: 600, y: 300 },
      'bnk-fn-post': { x: 750, y: 340 },
      'bnk-db-ledger': { x: 600, y: 180 },
      'bnk-srv-fraud': { x: 600, y: 60 },
      'bnk-queue-audit': { x: 420, y: 60 },
      'bnk-ext-swift': { x: 750, y: 180 },
      'bnk-ext-sanctions': { x: 750, y: 60 },
    };

    if (customPositions[nodeId]) {
      return customPositions[nodeId];
    }
    // Dynamic layered or circular layout for arbitrary repositories
    const angle = (index / Math.max(total, 1)) * 2 * Math.PI;
    return {
      x: 420 + Math.cos(angle) * 260,
      y: 210 + Math.sin(angle) * 140
    };
  };

  // Find root changed node and build downstream blast radius dynamically
  const changedNodes = new Set(graph.nodes.filter(n => n.isChanged).map(n => n.id));
  const downstreamImpacted = new Set<string>();

  // Add 1-hop and 2-hop downstream neighbors
  graph.edges.forEach(e => {
    if (changedNodes.has(e.source)) {
      downstreamImpacted.add(e.target);
    }
  });
  graph.edges.forEach(e => {
    if (downstreamImpacted.has(e.source)) {
      downstreamImpacted.add(e.target);
    }
  });

  const isAffected = (node: GraphNode) => {
    return node.isChanged || downstreamImpacted.has(node.id) || node.criticality === 'CRITICAL';
  };

  const filteredNodes = graph.nodes.filter(node => {
    if (showAffectedOnly && !isAffected(node)) return false;
    if (filterLayer === 'ALL') return true;
    if (filterLayer === 'SERVICES' && (node.type === 'Service' || node.type === 'API')) return true;
    if (filterLayer === 'DATA' && (node.type === 'Database' || node.type === 'Queue')) return true;
    if (filterLayer === 'CODE' && (node.type === 'Function' || node.type === 'File')) return true;
    return true;
  });

  const nodeMap = new Map(graph.nodes.map((n, i) => [n.id, { ...n, ...getNodeCoordinates(n.id, i, graph.nodes.length) }]));

  const filteredEdges = graph.edges.filter(edge => {
    if (showRuntimeOnly && edge.sourceType !== 'runtime') return false;
    const src = nodeMap.get(edge.source);
    const tgt = nodeMap.get(edge.target);
    if (!src || !tgt) return false;
    if (showAffectedOnly && (!isAffected(src) || !isAffected(tgt))) return false;
    return true;
  });

  const getNodeColor = (node: GraphNode) => {
    if (node.isChanged) return 'stroke-indigo-400 fill-indigo-950/90 text-indigo-200 ring-4 ring-indigo-500/30';
    if (downstreamImpacted.has(node.id)) return 'stroke-amber-400 fill-amber-950/80 text-amber-200';
    if (node.criticality === 'CRITICAL') return 'stroke-red-400 fill-red-950/70 text-red-200';
    return 'stroke-slate-700 fill-slate-900 text-slate-300';
  };

  return (
    <div className="relative w-full h-full bg-slate-950 flex flex-col select-none overflow-hidden">
      {/* Top Graph Controls Bar */}
      <div className="h-12 border-b border-slate-800 bg-slate-900/80 px-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mr-2">
            <Network className="w-4 h-4 text-indigo-400" />
            Dependency Map
          </span>

          {/* Layer Filter Chips */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-md p-0.5 text-xs">
            {(['ALL', 'SERVICES', 'DATA', 'CODE'] as const).map(layer => (
              <button
                key={layer}
                onClick={() => setFilterLayer(layer)}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  filterLayer === layer 
                    ? 'bg-indigo-600 text-white shadow-xs' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {layer}
              </button>
            ))}
          </div>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Toggle buttons */}
          <button
            onClick={() => setShowRuntimeOnly(!showRuntimeOnly)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
              showRuntimeOnly 
                ? 'bg-indigo-950 border-indigo-500 text-indigo-200' 
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-indigo-400" />
            <span>Observed Runtime Only</span>
          </button>

          <button
            onClick={() => setShowAffectedOnly(!showAffectedOnly)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
              showAffectedOnly 
                ? 'bg-amber-950 border-amber-500 text-amber-200' 
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span>Only Affected Subgraph</span>
          </button>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-md p-1">
          <button 
            onClick={() => setZoomLevel(prev => Math.min(prev + 0.15, 1.6))}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded"
            title="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setZoomLevel(prev => Math.max(prev - 0.15, 0.6))}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded"
            title="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setZoomLevel(1)}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded"
            title="Reset Zoom"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="flex-1 w-full h-full relative overflow-hidden flex items-center justify-center">
        {/* Subtle coordinate grid */}
        <div 
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle, #334155 1px, transparent 1px)`,
            backgroundSize: '24px 24px'
          }}
        />

        <svg 
          viewBox="0 0 850 440" 
          className="w-full h-full max-h-[560px] transition-transform duration-200"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <defs>
            <marker id="arrow-static" viewBox="0 0 10 10" refX="22" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
            </marker>
            <marker id="arrow-runtime" viewBox="0 0 10 10" refX="22" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#818cf8" />
            </marker>
            <marker id="arrow-affected" viewBox="0 0 10 10" refX="22" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#fbbf24" />
            </marker>
          </defs>

          {/* Render Edges */}
          {filteredEdges.map(edge => {
            const src = nodeMap.get(edge.source);
            const tgt = nodeMap.get(edge.target);
            if (!src || !tgt) return null;

            const isRuntime = edge.sourceType === 'runtime';
            const isHighImpactPath = (edge.source === 'srv-payment' || edge.source === 'fn-calc-total' || edge.target === 'srv-payment');

            return (
              <g key={edge.id} className="group">
                <line
                  x1={src.x}
                  y1={src.y}
                  x2={tgt.x}
                  y2={tgt.y}
                  stroke={isHighImpactPath ? '#f59e0b' : isRuntime ? '#818cf8' : '#334155'}
                  strokeWidth={isHighImpactPath ? 2.5 : isRuntime ? 2 : 1.5}
                  strokeDasharray={isRuntime ? '4 3' : undefined}
                  markerEnd={isHighImpactPath ? 'url(#arrow-affected)' : isRuntime ? 'url(#arrow-runtime)' : 'url(#arrow-static)'}
                  className="transition-all duration-300 group-hover:stroke-indigo-300"
                />
                {/* Edge Label for Telemetry */}
                {isRuntime && edge.metadata?.rps && (
                  <text
                    x={(src.x + tgt.x) / 2}
                    y={(src.y + tgt.y) / 2 - 8}
                    fill="#a5b4fc"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="middle"
                    className="bg-slate-950 px-1"
                  >
                    {edge.metadata.rps} req/s ({edge.metadata.p95_latency_ms}ms)
                  </text>
                )}
              </g>
            );
          })}

          {/* Render Nodes */}
          {filteredNodes.map(node => {
            const pos = nodeMap.get(node.id);
            if (!pos) return null;
            const isSelected = selectedNode?.id === node.id;
            const isRootChange = node.isChanged;

            return (
              <g 
                key={node.id} 
                transform={`translate(${pos.x}, ${pos.y})`}
                onClick={() => onSelectNode(isSelected ? null : node)}
                className="cursor-pointer group"
              >
                {/* Selection halo */}
                {isSelected && (
                  <circle r="30" fill="none" stroke="#6366f1" strokeWidth="2.5" strokeDasharray="3 3" className="animate-spin-slow" />
                )}

                {/* Main Node Circle/Pill */}
                <circle
                  r="20"
                  className={`${getNodeColor(node)} stroke-2 transition-all duration-200 group-hover:scale-110`}
                />

                {/* Central Glyph */}
                {node.type === 'Service' && <Server x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}
                {node.type === 'Database' && <Database x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}
                {node.type === 'Function' && <Terminal x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}
                {node.type === 'Queue' && <Radio x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}
                {node.type === 'API' && <Activity x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}
                {node.type === 'ExternalService' && <Network x="-8" y="-8" width="16" height="16" className="text-current pointer-events-none" />}

                {/* Node Text Label */}
                <text
                  y="34"
                  textAnchor="middle"
                  fill="#cbd5e1"
                  fontSize="11"
                  fontWeight={isRootChange ? '700' : '500'}
                  className="font-sans pointer-events-none drop-shadow-md"
                >
                  {node.name}
                </text>

                {/* Tag Badge */}
                {isRootChange && (
                  <g transform="translate(0, -26)">
                    <rect x="-32" y="-10" width="64" height="16" rx="4" fill="#4338ca" stroke="#6366f1" strokeWidth="1" />
                    <text x="0" y="2" fill="#ffffff" fontSize="9" fontWeight="700" textAnchor="middle">
                      CHANGED
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend Footer */}
      <div className="h-9 border-t border-slate-800 bg-slate-900/90 px-4 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 border border-indigo-300" />
            <span>Root Changed Node</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 border border-amber-300" />
            <span>Direct Impact Component</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500 border border-orange-300" />
            <span>Indirect Impact Path</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 border-t-2 border-dashed border-indigo-400" />
            <span>Runtime Telemetry Tracing</span>
          </div>
        </div>
        <div className="font-mono text-slate-500">
          Nodes: {filteredNodes.length} • Edges: {filteredEdges.length}
        </div>
      </div>
    </div>
  );
};
