import React from 'react';
import { 
  FolderGit2, 
  Layers, 
  FileCode2, 
  Database, 
  CheckCircle2, 
  AlertTriangle, 
  GitBranch, 
  Clock, 
  Activity, 
  ChevronRight,
  PlusCircle,
  ExternalLink,
  ShieldCheck,
  Zap,
  Server
} from 'lucide-react';
import { RepositorySummary } from '../../types/repository.ts';
import { DEMO_REPOSITORIES } from '../../data/repositories.ts';

interface RepositoryExplorerViewProps {
  selectedRepository: RepositorySummary;
  onSelectRepository: (repo: RepositorySummary) => void;
  onSelectCommitAndAnalyze: (repo: RepositorySummary, commitSha: string) => void;
  onOpenImportModal: () => void;
}

export const RepositoryExplorerView: React.FC<RepositoryExplorerViewProps> = ({
  selectedRepository,
  onSelectRepository,
  onSelectCommitAndAnalyze,
  onOpenImportModal
}) => {
  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200 p-6 overflow-y-auto">
      {/* Top Banner: Repository-Agnostic Paradigm */}
      <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-900/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-mono text-xs font-semibold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Repository-Agnostic AI Platform</span>
          </div>
          <h2 className="text-lg font-bold text-slate-100">
            Software Project Registry & Structural Topologies
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">
            The change-risk engine operates uniformly across arbitrary software domains. Select any target repository below to load its project-specific architecture, dependency topologies, runtime telemetry streams, and historical incidents.
          </p>
        </div>

        <button
          onClick={onOpenImportModal}
          className="flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Import / Connect Repository</span>
        </button>
      </div>

      {/* Repositories Grid */}
      <div className="mb-8">
        <h3 className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
          <FolderGit2 className="w-4 h-4 text-indigo-400" />
          Available Repositories ({DEMO_REPOSITORIES.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {DEMO_REPOSITORIES.map((repo) => {
            const isSelected = repo.id === selectedRepository.id;
            return (
              <div
                key={repo.id}
                onClick={() => onSelectRepository(repo)}
                className={`cursor-pointer rounded-xl p-4 border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-900/90 border-indigo-500 ring-1 ring-indigo-500/50 shadow-md'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800/60">
                      {repo.category}
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${
                      repo.health === 'HEALTHY' ? 'text-emerald-400 bg-emerald-950/60' : 'text-amber-400 bg-amber-950/60'
                    }`}>
                      {repo.health}
                    </span>
                  </div>

                  <h4 className="font-semibold text-slate-100 text-sm mb-1 leading-snug">
                    {repo.name}
                  </h4>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-3 leading-relaxed">
                    {repo.description}
                  </p>
                </div>

                <div className="border-t border-slate-800 pt-2.5 mt-2 space-y-1.5 text-[11px] font-mono text-slate-400">
                  <div className="flex justify-between">
                    <span>Services & APIs:</span>
                    <span className="text-slate-200 font-semibold">{repo.servicesCount} srv / {repo.apisCount} api</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Regression Tests:</span>
                    <span className="text-slate-200 font-semibold">{repo.testsCount} tests</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Prior Incidents:</span>
                    <span className="text-slate-200 font-semibold">{repo.historicalIncidentCount} recorded</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Repository Deep-Dive */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-800 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[11px] font-mono font-bold bg-indigo-600/20 text-indigo-300 rounded border border-indigo-500/30">
                ACTIVE REPOSITORY
              </span>
              <h3 className="text-base font-bold text-slate-100">
                {selectedRepository.name}
              </h3>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-400 mt-1 font-mono">
              <span className="flex items-center gap-1">
                <GitBranch className="w-3.5 h-3.5 text-indigo-400" />
                branch: {selectedRepository.branch}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                Telemetry: {selectedRepository.telemetrySource}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {selectedRepository.languages.map((lang, idx) => (
              <span key={idx} className="px-2 py-1 bg-slate-950 border border-slate-800 rounded text-[11px] font-mono text-slate-300">
                {lang}
              </span>
            ))}
          </div>
        </div>

        {/* Repository Architectural Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 my-4">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Source Files</span>
            <span className="text-lg font-bold text-slate-200 font-mono">{selectedRepository.filesCount}</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Services</span>
            <span className="text-lg font-bold text-indigo-300 font-mono">{selectedRepository.servicesCount}</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Endpoints (APIs)</span>
            <span className="text-lg font-bold text-slate-200 font-mono">{selectedRepository.apisCount}</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Databases</span>
            <span className="text-lg font-bold text-slate-200 font-mono">{selectedRepository.databasesCount}</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Test Suites</span>
            <span className="text-lg font-bold text-emerald-400 font-mono">{selectedRepository.testsCount}</span>
          </div>
        </div>

        {/* Commits & Changes for this Repository */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <FileCode2 className="w-4 h-4 text-indigo-400" />
              Recent Commits Ready for Change-Risk Analysis
            </h4>
            <span className="text-[11px] text-slate-500 font-mono">
              Select a commit below to run dynamic graph traversal & AI prediction
            </span>
          </div>

          <div className="space-y-2">
            {selectedRepository.commits.map((c) => (
              <div
                key={c.sha}
                className="bg-slate-950 border border-slate-800 hover:border-indigo-500/50 rounded-lg p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 transition-colors"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs font-bold text-indigo-400">
                      {c.sha.substring(0, 7)}
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-slate-300">
                      {c.changeType}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      by {c.author} • {new Date(c.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-xs font-medium text-slate-200">
                    {c.message}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {c.diffSummary}
                  </p>
                </div>

                <button
                  onClick={() => onSelectCommitAndAnalyze(selectedRepository, c.sha)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold shadow-xs transition-colors shrink-0"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Analyze This Change</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
