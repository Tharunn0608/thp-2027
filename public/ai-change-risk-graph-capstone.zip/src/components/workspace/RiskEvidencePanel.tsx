import React from 'react';
import { 
  ShieldAlert, 
  Sparkles, 
  FileText, 
  Radio, 
  History, 
  Activity, 
  ExternalLink,
  ChevronRight,
  Info,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';
import { AnalysisResult, GraphNode, EvidenceItem } from '../../types.ts';

interface RiskEvidencePanelProps {
  analysis: AnalysisResult;
  selectedNode: GraphNode | null;
  onClearSelectedNode: () => void;
  onSelectEvidence: (evidenceId: string) => void;
}

export const RiskEvidencePanel: React.FC<RiskEvidencePanelProps> = ({ 
  analysis, 
  selectedNode, 
  onClearSelectedNode,
  onSelectEvidence
}) => {
  const { risk, explanation, evidence, affectedComponents } = analysis;

  const getScoreBarColor = (score: number) => {
    if (score >= 75) return 'bg-red-500';
    if (score >= 50) return 'bg-amber-500';
    if (score >= 25) return 'bg-yellow-500';
    return 'bg-emerald-500';
  };

  const getEvidenceIcon = (type: EvidenceItem['type']) => {
    switch (type) {
      case 'runtime':
        return <Activity className="w-3.5 h-3.5 text-indigo-400" />;
      case 'history':
        return <History className="w-3.5 h-3.5 text-amber-400" />;
      case 'temporal':
        return <Radio className="w-3.5 h-3.5 text-cyan-400" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="flex flex-col gap-4 p-4 text-slate-200 text-sm overflow-y-auto h-full">
      {/* Node Inspector Drawer if selected */}
      {selectedNode ? (
        <div className="bg-indigo-950/40 border border-indigo-500/50 rounded-lg p-3.5 mb-1 animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-semibold uppercase text-indigo-300">
              Selected Entity
            </span>
            <button 
              onClick={onClearSelectedNode}
              className="text-xs text-slate-400 hover:text-white px-1.5 py-0.5 rounded hover:bg-indigo-900/50"
            >
              ✕ Close
            </button>
          </div>
          <div className="font-semibold text-slate-100">{selectedNode.name}</div>
          <div className="text-xs text-slate-400 font-mono mt-0.5">Type: {selectedNode.type}</div>
          {selectedNode.criticality && (
            <div className="text-xs text-slate-300 mt-2 flex items-center gap-1.5">
              <span>Criticality Tier:</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold ${
                selectedNode.criticality === 'CRITICAL' ? 'text-red-400 bg-red-950/60' : 'text-amber-400 bg-amber-950/60'
              }`}>
                {selectedNode.criticality}
              </span>
            </div>
          )}
          {selectedNode.metadata && (
            <div className="mt-2 text-xs bg-slate-900/80 p-2 rounded border border-slate-800 font-mono text-[11px] text-slate-400">
              {JSON.stringify(selectedNode.metadata, null, 2)}
            </div>
          )}
        </div>
      ) : null}

      {/* Quantitative Risk Score Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span className="font-semibold text-slate-300 tracking-wider uppercase">Predictive Risk Score</span>
          <span className="font-mono">{risk.score} / 100</span>
        </div>
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden my-2">
          <div 
            className={`h-full ${getScoreBarColor(risk.score)} transition-all duration-500`}
            style={{ width: `${risk.score}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-xs mt-3 pt-2 border-t border-slate-800/80">
          <div className="flex flex-col">
            <span className="text-[11px] text-slate-500">Confidence Metric</span>
            <span className="font-mono font-medium text-slate-300">{(risk.confidence * 100).toFixed(0)}% Reliable</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[11px] text-slate-500">Calibrated P(Adverse)</span>
            <span className="font-mono font-medium text-slate-300">{(risk.calibratedProbability * 100).toFixed(0)}%</span>
          </div>
        </div>
        <div className="mt-2 text-[10px] text-slate-500 font-mono text-right">
          Model: {risk.modelId} ({risk.modelVersion})
        </div>
      </div>

      {/* Evidence-Grounded AI Explanation Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Evidence-Grounded Explanation
          </span>
          <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">
            {explanation.generatedBy}
          </span>
        </div>
        <div className="text-xs text-slate-300 leading-relaxed font-sans mb-3">
          {explanation.summary}
        </div>
        <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80 text-xs text-slate-400 leading-relaxed">
          <div className="font-medium text-slate-200 mb-1 flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-indigo-400" />
            Causal & Dependency Rationale:
          </div>
          {explanation.whyRisky}
        </div>
        <div className="mt-3 text-xs bg-amber-950/20 border border-amber-800/40 p-2.5 rounded text-amber-300/90 leading-relaxed">
          <span className="font-semibold">Recommended Mitigation: </span>
          {explanation.suggestedMitigation}
        </div>
      </div>

      {/* Structured Point-in-Time Evidence List */}
      <div>
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>Point-in-Time Evidence ($T_0$)</span>
          <span className="font-mono text-slate-500">({evidence.length} items)</span>
        </div>
        <div className="flex flex-col gap-2">
          {evidence.map((ev) => (
            <div
              key={ev.id}
              onClick={() => onSelectEvidence(ev.id)}
              className="bg-slate-900/70 border border-slate-800 hover:border-slate-700 p-2.5 rounded-lg transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="flex items-center gap-1.5 font-medium text-slate-200">
                  {getEvidenceIcon(ev.type)}
                  <span className="uppercase text-[10px] font-mono text-slate-400 tracking-wider">
                    {ev.type}
                  </span>
                </span>
                <span className="font-mono text-[10px] text-slate-500">
                  {ev.sourceReference}
                </span>
              </div>
              <p className="text-xs text-slate-300 group-hover:text-slate-100 transition-colors">
                {ev.summary}
              </p>
              <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                <span>Timestamp: {new Date(ev.timestamp).toLocaleTimeString()}</span>
                <span>Contribution: {(ev.weight * 100).toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
